import sys
import PyQt5
from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5 import uic




class MyWidget(QMainWindow):
	def __init__(self):
		super().__init__()
		uic.loadUi('меню.ui', self)


		self.pushButton.clicked.connect(self.Ruls)
		self.pushButton_2.clicked.connect(self.play)
		self.pushButton_3.clicked.connect(self.results)

		self.present_coin()

	def present_coin(self):
		with open('монеты.txt', 'r') as lines:
			for o in lines:
				self.coinss = int(o)
				self.label_coin2.setText(str(self.coinss))


	def Ruls(self):
		self.second_form = SecondForm()
		self.second_form.show()

	def play(self):
		import cod_of_game

	def results(self):
		self.third_form = ThirdForm()
		self.third_form.show()

class SecondForm(QMainWindow):
	def __init__(self):
		super().__init__()
		uic.loadUi('правила.ui', self)

class ThirdForm(QMainWindow):
	def __init__(self):
		super().__init__()
		uic.loadUi('results.ui', self)
		w = open('результаты.txt', 'r')
		lines = w.readlines()
		self.label.setText('\n'.join(lines))


if __name__ == '__main__':
	app = QApplication(sys.argv)
	ex = MyWidget()
	ex.show()
	sys.exit(app.exec())