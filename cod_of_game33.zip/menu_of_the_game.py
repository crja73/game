import sys
import PyQt5
from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5 import uic




class MyWidget(QMainWindow):
	def __init__(self):
		super().__init__()
		uic.loadUi('меню.ui', self)

		self.pushButton.clicked.connect(self.Ruls)
		self.pushButton_2.clicked.connect(self.play)
		self.pushButton_3.clicked.connect(self.results)


	def money(self):
		with open('монеты.txt', 'r') as lines:
			for o in lines:
				self.coinss = int(o)
				self.label_coin2.setText(str(self.coinss))	



	def Ruls(self):
		self.second_form = SecondForm()
		self.second_form.show()

	def play(self):
		import cod_of_game
	

	def results(self):
		#with open('.txt', 'r') as lines:
			#for i in lines:
		pass

class SecondForm(QMainWindow):
	def __init__(self):
		super().__init__()
		uic.loadUi('правила.ui', self)


if __name__ == '__main__':
	app = QApplication(sys.argv)
	ex = MyWidget()
	print(ex.money())
	ex.show()
	sys.exit(app.exec())